import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'

Vue.config.productionTip = false
var $ = require("jquery");

new Vue({
  router,
  store,
  render: h => h(App),
  created() {
    var res = fetch('http://tc.geeksforless.net/~user11/perlproject/router/router.cgi')
    console.log(res)
  },
}).$mount('#app')
