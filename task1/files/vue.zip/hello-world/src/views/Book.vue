<template>
  <div class="home">
    <Book :one_book="book"/>
  </div>
</template>

<script>
// @ is an alias to /src
import Book from '@/components/Book.vue'

export default {
  name: 'book-view',
  data: function(){
    return {
      book: {}
    }
  },
  components: {
    Book 
  },
  created(){
    this.book = {
        id:1,
        name:'book1',
        description:'lorem blablabla',
        picture:require('./../assets/book-1.png')
      }
  }
}
</script>