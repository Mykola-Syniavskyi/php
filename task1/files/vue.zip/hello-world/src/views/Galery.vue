<template>
<div>
<div class="nav">
  <ul class="nav-list">
    <li class="nav-list__item" v-for="item in authors" :key="item.id">
      {{item.id}} : {{item.name}}
    </li>
  </ul>
  <ul class="nav-list">
    <li class="nav-list__item" v-for="item in genres" :key="item.id">
      {{item.id}} : {{item.name}}
    </li>
  </ul>

</div>
  <div class="home">
    <Books :shop_p="shop" msg="All books"/>
  </div>
</div>

</template>

<script>
// @ is an alias to /src
import Books from '@/components/Books.vue'
window.$ = window.jQuery = require('jquery')

export default {
  name: 'galery-view',
  data: function(){
    return {
      shop: [],
      authors: [],
      genres: []
    }
  },
  components: {
    Books
  },
  methods: {
    getBooksOneAuthor(id){
      console.log(id)
    },
    getBooksOneGenre(id){
      console.log(id)
    },
    getAllBooks(){
      console.log('all')
    },
    startPage(){
      this.shop = [{
        id:1,
        name:'book1',
        description:'lorem blablabla',
        picture:  require('./../assets/book-1.png')
      },
      {
        id:2,
        name:'book2',
        description:'lorem blablabla',
        picture: require('./../assets/book-2.png')
      },
      {
        id:3,
        name:'book3',
        description:'lorem blablabla',
        picture: require('./../assets/book-3.png')
      }]
      this.authors = [{
        id: 1,
        name: 'Brejnev'
      },
      {
        id: 2,
        name: 'Vasia'
      },
      {
        id: 3,
        name: 'Anjey'
      }]
      this.genres = [{
        id: 1,
        name: 'Fantasy'
      },
      {
        id: 2,
        name: 'Novel'
      },
      {
        id: 3,
        name: 'Classic'
      }]
    }
  },
  created(){
    this.startPage();
  }
}
</script>

<style scoped lang="scss">

.nav{
display: flex;
  &-list{
    max-width: 200px;
    width: 100%;
    list-style: none;
    &__item{
      font-family: monospace;
      color: blue;
    }   
  }
}
</style>