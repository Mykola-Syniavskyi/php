<template>
  <div class="hello">
    <ul>
      <li >
        <p>{{one_book.id}}</p>
        <p>{{one_book.name}}</p>
        <p>{{one_book.description}}</p>
        <img  :src="one_book.picture" :alt="one_book.name">
        </li>
    </ul>
  </div>
</template>

<script>
export default {
  name: 'book-components',
  props: {
   one_book: Object
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">

</style>
