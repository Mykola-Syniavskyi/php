<template>
  <div class="hello">
    <h1>{{ msg }}</h1>
    <ul class="book">
      <li class="book-item" v-for="item in shop_p" :key="item.id">
        <img class="book-item__img"  :src="item.picture" alt="1">
        <router-link :to="'/'+item.id">{{item.name}}</router-link> 
        <p>{{item.description}}</p>
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  name: 'books-components',
  props: {
    msg: String,
    shop_p: Array
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #5880da;
  font-size: 20px;
  font-weight: bold;
  text-decoration: none;
}
.book{
  display: flex;
  flex-wrap: wrap;
  &-item{
    display: flex;
    flex-direction: column;
    align-items: center;
    width: 100%;
    max-width: 300px;
    padding: 5px;
    border:1px solid #fff;
    border-radius: 8px;
    &:hover{
      box-shadow: 0px 0px 4px #5880da;
    }
    &__img{
      width: 280px;
      height: 330px;
    }
  }
}
</style>
